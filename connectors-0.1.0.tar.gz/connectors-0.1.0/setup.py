from setuptools import setup, find_packages

setup(name='connectors',
      version='0.1.0',
      url='https://github.com/luchanos/connectors',
      author='luchanos',
      author_email='lukash_91@mail.ru',
      description='Connectors for API',
      packages=find_packages(exclude=['tests']),
      long_description=open('README.md').read(),
      zip_safe=False)
