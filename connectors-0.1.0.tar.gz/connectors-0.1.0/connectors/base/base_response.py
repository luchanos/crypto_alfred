import aiohttp


class BaseResponse:
    def __init__(self):
        self._json = None
        self._text = None
        self.status = None
        self._headers = None
        self.cookies = None
        self._response = None
        self.url = None
        self.method = None

    async def json(self):
        return self._json

    async def text(self):
        return self._text

    @classmethod
    async def create_from_response(cls, response: aiohttp.ClientResponse):
        resp = cls()
        resp._text = await response.text()

        resp.status = response.status
        resp._headers = response.headers
        resp.cookies = response.cookies
        resp.method = response.method
        resp.url = response.url
        resp._response = response

        res = await response.json(encoding="utf8", content_type=None)
        resp._json = {"success": response.ok, "result": res}
        return resp

    @property
    def headers(self):
        return self._headers

    async def json_result(self) -> dict:
        json = await self.json()
        result = json.get("result")
        return result

    async def is_json_successful(self) -> bool:
        json = await self.json()
        success = json.get("success")
        return bool(success)
