from copy import deepcopy
from types import TracebackType
from typing import Optional, Type
from urllib.parse import urljoin

import aiohttp

from connectors.base.base_response import BaseResponse


class BaseClient:
    response_cls = BaseResponse

    def __init__(self, base_url: str, *args, **kwargs):
        self._base_url = base_url
        self._session = aiohttp.ClientSession(raise_for_status=False)

    @classmethod
    def create(cls, base_url, **kwargs):
        client = cls(base_url=base_url, **kwargs)
        return client

    async def close(self) -> None:
        return await self._session.close()

    async def __aenter__(self):
        return self

    async def __aexit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> Optional[bool]:
        await self.close()
        return None

    @property
    def default_headers(self):
        return {}

    def build_url(self, uri: str):
        url = "{}/".format(self._base_url.rstrip("/"))
        uri = uri.strip("/")

        return urljoin(url, uri)

    async def _request(self, method: str, url: str, **kwargs):
        json = kwargs.get("json")
        params = kwargs.get("params")
        headers = deepcopy(self.default_headers)
        headers.update(kwargs.get("headers", {}))
        response_cls = self.response_cls

        async with self._session.request(
            method=method, url=url, json=json, params=params, headers=headers
        ) as response:
            return await response_cls.create_from_response(response)

    async def get(self, url: str, **kwargs):
        return await self._request(method="get", url=url, **kwargs)

    async def post(self, url: str, **kwargs):
        return await self._request(method="post", url=url, **kwargs)

    async def delete(self, url: str, **kwargs):
        return await self._request(method="delete", url=url, **kwargs)

    async def put(self, url: str, **kwargs):
        return await self._request(method="put", url=url, **kwargs)

    async def patch(self, url: str, **kwargs):
        return await self._request(method="patch", url=url, **kwargs)
