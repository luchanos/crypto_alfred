from connectors.base.base_client import BaseClient


class UsersApiClient(BaseClient):
    async def create_user(
        self,
        user_id: int,
        chat_id: int,
        lang: str,
        username: str = None,
        first_name: str = None,
        last_name: str = None,
    ) -> dict:
        url = self.build_url("/user/")
        json = {
            "user_id": user_id,
            "chat_id": chat_id,
            "username": username,
            "first_name": first_name,
            "last_name": last_name,
            "lang": lang,
        }
        res = await self.post(url, json=json)
        return await res.json_result()

    async def update_lang(self, user_id: int, lang: str):
        url = self.build_url("/user/update_lang/")
        params = {"user_id": user_id}
        json = {"lang": lang}
        res = await self.patch(url, params=params, json=json)
        return await res.json_result()

    async def recreate_user(self, user_id: int):
        url = self.build_url("/user/recreate_user/")
        params = {"user_id": user_id}
        res = await self.patch(url, params=params)
        return await res.json_result()

    async def get_user(self, user_id: int) -> dict:
        url = self.build_url("/user/")
        params = {"user_id": user_id}
        res = await self.get(url, params=params)
        return await res.json_result()

    async def get_deleted_user(self, user_id: int) -> dict:
        url = self.build_url("/user/get_deleted/")
        params = {"user_id": user_id}
        res = await self.get(url, params=params)
        return await res.json_result()

    async def delete_user(self, user_id) -> dict:
        url = self.build_url("/user/")
        params = {"user_id": user_id}
        res = await self.delete(url, params=params)
        return await res.json_result()

    async def update_message_rating_single_user(self, user_id: int) -> dict:
        url = self.build_url("/user/message_rating/")
        params = {"user_id": user_id}
        res = await self.post(url, params=params)
        return await res.json_result()

    async def create_or_update_message(self, from_user: int, message_id: int, message_rating: int) -> dict:
        url = self.build_url("/message/")
        json = {"from_user": from_user, "message_id": message_id, "message_rating": message_rating}
        res = await self.post(url, json=json)
        return await res.json_result()

    async def get_message_info(self, message_id: int):
        url = self.build_url("/message/")
        params = {"message_id": message_id}
        res = await self.get(url, params=params)
        return await res.json_result()

    async def create_common_message_rating_event(self, user_id: int, value: int, event_type: str) -> dict:
        url = self.build_url("/user/common_rating_event/")
        json = {"user_id": user_id, "value": value, "event_type": event_type}
        res = await self.post(url, json=json)
        return await res.json_result()

    async def update_message_rating_all_users(self):
        url = self.build_url("/user/message_rating_all/")
        res = await self.post(url)
        return await res.is_json_successful()

    async def update_accept_rules(self, user_id: int):
        url = self.build_url("/user/update_accept_rules/")
        params = {"user_id": user_id}
        res = await self.patch(url, params=params)
        return await res.json_result()

    async def update_referral_link(self, user_id: int, referral_link: str):
        url = self.build_url("/user/update_referral_link/")
        params = {"user_id": user_id}
        json = {"referral_link": referral_link}
        res = await self.patch(url, params=params, json=json)
        return await res.json_result()

    async def update_common_rating_referral(self, referral_link: str, rating_value: int):
        url = self.build_url("/user/update_common_rating_referral/")
        json = {"referral_link": referral_link, "common_rating": rating_value}
        res = await self.patch(url, json=json)
        return await res.json_result()

    async def send_rating_to_other_user(self, from_user: int, to_user: int, amount: int):
        url = self.build_url("/user/send_rating_to_other_user/")
        json = {"from_user": from_user, "to_user": to_user, "amount": amount}
        res = await self.post(url, json=json)
        return await res.json_result()

    async def get_user_by_referral_link(self, referral_link: str):
        url = self.build_url("/user/get_by_referral_link/")
        json = {"referral_link": referral_link}
        res = await self.post(url, json=json)
        return await res.json_result()
