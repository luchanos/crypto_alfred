from typing import Optional
from uuid import uuid4

from connectors.base.base_client import BaseClient


class TelegramClient(BaseClient):
    async def send_message(self, chat_id: int, text: str, parse_mode: Optional[str] = None) -> dict:
        url = self.build_url("/sendMessage/")

        message = {"chat_id": chat_id, "text": text}
        if parse_mode:
            message["parse_mode"] = parse_mode

        response = await self.post(url, json=message)
        return await response.json_result()

    async def send_photo(self, chat_id: int, photo):
        url = self.build_url("/sendPhoto/")
        json = {"chat_id": chat_id, "photo": photo}
        response = await self.post(url, json=json)
        return await response.json_result()

    @staticmethod
    def create_params(**kwargs):
        params = {}
        if expire_date := kwargs.get("expire_date"):
            params["expire_date"] = expire_date
        if member_limit := kwargs.get("member_limit"):
            params["member_limit"] = member_limit
        if creates_join_request := kwargs.get("creates_join_request") is not None:
            params["creates_join_request"] = str(creates_join_request)
        return params

    async def generate_invite_link(self, chat_id: str, **kwargs) -> dict:
        url = self.build_url("/createChatInviteLink/")
        uuid_id = uuid4().hex
        params = {"chat_id": chat_id, "name": uuid_id, **self.create_params(**kwargs)}
        response = await self.post(url, params=params)
        return await response.json_result()

    async def approve_chat_join_request(self, chat_id: int, user_id: int, **kwargs):
        url = self.build_url("/approveChatJoinRequest/")
        params = {"chat_id": chat_id, "user_id": user_id, **self.create_params(**kwargs)}
        response = await self.get(url, params=params)
        return await response.json_result()
