from typing import Optional

from connectors.base.base_client import BaseClient


class CoinApiClient(BaseClient):
    api_key: str = ""

    @classmethod
    def create(cls, base_url, **kwargs):
        api_key = kwargs.pop("api_key")
        client = super().create(base_url=base_url, **kwargs)
        client.api_key = api_key
        return client

    @property
    def default_headers(self):
        return {"X-CoinAPI-Key": self.api_key}

    async def get_exchange_rates(self, currency_tokens: Optional[list[str]]):
        url = self.build_url("/v1/assets/")
        params = {"filter_asset_id": ",".join(currency_tokens)}
        res = await self.get(url, params=params)
        return await res.json_result()
