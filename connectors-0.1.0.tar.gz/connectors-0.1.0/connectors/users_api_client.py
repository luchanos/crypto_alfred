from types import TracebackType
from typing import Optional, Type
import aiohttp


class UsersApiClient:
    def __init__(self, base_url: str) -> None:
        self._base_url = base_url
        self._client = aiohttp.ClientSession(raise_for_status=False)

    async def close(self) -> None:
        return await self._client.close()

    async def __aenter__(self) -> "UsersApiClient":
        return self

    async def __aexit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> Optional[bool]:
        await self.close()
        return None

    async def create_user(self, user_id: int, chat_id: int, username: str) -> dict:
        async with self._client.post(f"{self._base_url}/user", json={"user_id": user_id,
                                                                     "chat_id": chat_id,
                                                                     "username": username}) as resp:
            ret = await resp.json()
            return {"Success": True if resp.ok else False, "result": ret}

    async def get_user(self, user_id: int) -> dict:
        async with self._client.get(f"{self._base_url}/user?user_id={user_id}") as resp:
            ret = await resp.json()
            return {"Success": True if resp.ok else False, "result": ret}

    async def delete_user(self, user_id) -> dict:
        async with self._client.delete(f"{self._base_url}/user?user_id={user_id}") as resp:
            ret = await resp.json()
            return {"Success": True if resp.ok else False, "result": ret}

    async def create_or_update_message(self, from_user: int, message_id: int, message_rating: int):
        async with self._client.post(f"{self._base_url}/message", json={"from_user": from_user,
                                                                        "message_id": message_id,
                                                                        "message_rating": message_rating}) as resp:
            ret = await resp.json()
            return {"Success": True if resp.ok else False, "result": ret}

    async def force_update_user_common_message_rating(self, user_id: int, ):
        async with self._client.post(f"{self._base_url}/user/message_rating?user_id={user_id}") as resp:
            ret = await resp.json()
            return {"Success": True if resp.ok else False, "result": ret}
